#!/bin/bash
python wallet_bot.py